var express = require('express');
var router = express.Router();
var mongodb = require("mongodb");
const MongoClient = require("mongodb").MongoClient;


/* GET home page. */
router.get('/', function (req, res, next) {
  res.render('index', { title: 'Express' });
});
router.get('/data', async function (req, res, next) {
  let url = "mongodb://127.0.0.1:27017/"
  const client = new MongoClient(url);
  await client.connect()
  let db = client.db("almaz")
  let collection = db.collection("almaz")
  let user = {
    name: req.query.name,
    email: req.query.email
  }
  console.log(user)
  await collection.insertOne(user)
  client.close()
  res.render('index', { title: 'Express' });
});

router.get('/alluser', async function (req, res, next) {
  // let url = "mongodb://127.0.0.1:27017/"
  // const client = new MongoClient(url);
  // await client.connect()
  // let db = client.db("almaz")
  // let collection = db.collection("almaz")
  // await collection.find({}).toArray(function(err, result) {
  //   if (err) throw err;
  //   console.log(result)
  //   const temp = result;
  //   console.log(temp)
  //   res.render('alluser', { result : temp});
  //   db.close();

  // })

  const url = "mongodb://127.0.0.1:27017/";
  const mongoClient = new MongoClient(url);

  async function run() {
    try {
      await mongoClient.connect();
      const db = mongoClient.db("almaz");
      const collection = db.collection("almaz");
      const results = await collection.find().toArray();
      console.log(results);
      res.render("alluser", {
        result: results
      })

    } catch (err) {
      console.log(err);
    } finally {
      await mongoClient.close();
    }
  }
  run().catch(console.error);

});
router.get('/searchuserView',async function(req,res){
res.render('searchuser')
})
router.get('/searchuser',async function(req,res){
  const client = new MongoClient("mongodb://127.0.0.1:27017/");
  await client.connect();
  let db = client.db("almaz")
  let collection = db.collection("almaz")
  const searchChar = req.query.almaz.charAt(0)
  const query = { name: { $regex: `^${searchChar}` } };
  let results = await collection.find(query).toArray();
  console.log(req.query.almaz[0])
  console.log (results)
  res.render("alluser", {
    result: results
  })
})




module.exports = router;
